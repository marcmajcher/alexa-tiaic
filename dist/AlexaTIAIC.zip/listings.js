'use strict';

/* eslint-env node */

exports.all = () => ({
  test: 'all'
});
